﻿#include <iostream>         // cout, cerr
#include <cstdlib>          // EXIT_FAILURE
#include <GL/glew.h>        // GLEW library
#include <GLFW/glfw3.h>     // GLFW library

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <camera.h> // Camera class

#define STB_IMAGE_IMPLEMENTATION
#include <stb_image.h>      // Image loading Utility functions

using namespace std; // Standard namespace

/*Shader program Macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

// Unnamed namespace
namespace
{
    const char* const WINDOW_TITLE = "3D Scene"; // Macro for window title

    // Variables for window width and height
    const int WINDOW_WIDTH = 800;
    const int WINDOW_HEIGHT = 600;

    // Stores the GL data relative to a given mesh
    struct GLMesh
    {
        GLuint vao;         // Handle for the vertex array object scene
        GLuint vao2;         // Handle for the vertex array object couch top and base
        GLuint vao3;         // Handle for the vertex array object couch arms
        GLuint vao4;         // Handle for the vertex array object floor
        GLuint vbos[8];     // Handles for the vertex buffer objects
        GLuint nIndices;    // Number of indices of the mesh
        GLuint nIndicesC;    // Number of indices of the mesh for the couch base and top
        GLuint nIndicesA;    // Number of indices of the mesh for the couch arms
        GLuint nIndicesF;    // Number of indices of the mesh for the floor
    };

    // Main GLFW window
    GLFWwindow* gWindow = nullptr;
    // Triangle mesh data
    GLMesh gMesh;
    // Texture id 1
    GLuint gTextureId;
    // Texture id 2
    GLuint gTextureId2;
    // Texture id 3
    GLuint gTextureId3;
    // Texture id 4
    GLuint gTextureId4;

    GLint modelLoc;
    GLint viewLoc;
    GLint projLoc;


    glm::vec2 gUVScale(1.0f, 1.0f);
    GLint gTexWrapMode = GL_REPEAT;

    // Shader programs
    GLuint gCubeProgramId;
    GLuint gLampProgramId;

    //camera location and orientation
    Camera gCamera(glm::vec3(0.0f, 0.0f, 3.0f));
    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;
    bool gFirstMouse = true;
    bool perspective = true;

    // timing
    float gDeltaTime = 0.0f; // time between current frame and last frame
    float gLastFrame = 0.0f;

    // Subject position and scale
    glm::vec3 gCubePosition(0.0f, 0.0f, 0.0f);
    glm::vec3 gCubeScale(2.0f);

    // Cube and light color point light 
    glm::vec3 gObjectColor(1.f, 0.2f, 0.0f);
    //purple point light
    glm::vec3 gLightColor(1.0f, 0.0f, 1.0f);

    // Light position and scale for point light and lamp
    glm::vec3 gLightPosition(5.5f, 2.5f, -1.0f);
    glm::vec3 gLightScale(0.3f);


    //directional light color COLOR IS CORAL
    glm::vec3 gLightColor2(1.0f, 0.5f, 0.31f);
    //directional light direction
    glm::vec3 direction(-0.2f, -1.0f, -0.3f);

}

/* User-defined Function prototypes to:
 * initialize the program, set the window size,
 * redraw graphics on the window when resized,
 * process keyboard and mouse input,
 * and render graphics on the screen
 */
bool UInitialize(int, char* [], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);
void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods);
void UCreateMesh(GLMesh& mesh);
void UDestroyMesh(GLMesh& mesh);
bool UCreateTexture(const char* filename, GLuint& textureId);
void UDestroyTexture(GLuint textureId);
void URender();
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);


/* Cube Vertex Shader Source Code*/
const GLchar* cubeVertexShaderSource = GLSL(440,

    layout(location = 0) in vec3 position; // VAP position 0 for vertex position data
layout(location = 1) in vec3 normal; // VAP position 1 for normals
layout(location = 2) in vec2 textureCoordinate;

out vec3 vertexNormal; // For outgoing normals to fragment shader
out vec3 vertexFragmentPos; // For outgoing color / pixels to fragment shader
out vec2 vertexTextureCoordinate;

//Uniform / Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates

    vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment / pixel position in world space only (exclude view and projection)

    vertexNormal = mat3(transpose(inverse(model))) * normal; // get normal vectors in world space only and exclude normal translation properties
    vertexTextureCoordinate = textureCoordinate;
}
);


/* Cube Fragment Shader Source Code*/

//****includes both point light and directional light****
const GLchar* cubeFragmentShaderSource = GLSL(440,

    in vec3 vertexNormal; // For incoming normals
in vec3 vertexFragmentPos; // For incoming fragment position
in vec2 vertexTextureCoordinate;

out vec4 fragmentColor; // For outgoing cube color to the GPU

// Uniform / Global variables for object color, light color, light position, and camera/view position
//directional light variables
uniform vec3 directionL;
uniform vec3 lightColor2;

//point light variables
uniform vec3 objectColor;
uniform vec3 lightColor;
uniform vec3 lightPos;
uniform vec3 viewPosition;
uniform sampler2D uTexture; // Useful when working with multiple textures
uniform vec2 uvScale;

void main()
{

    /*Phong lighting model calculations to generate ambient, diffuse, and specular components*/

    //----------point light calculations---------
    //Calculate Ambient lighting*/
    float ambientStrength = 0.1f; // Set ambient or global lighting strength
    vec3 ambient = ambientStrength * lightColor; // Generate ambient light color

    //Calculate Diffuse lighting*/
    vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit
    vec3 lightDirection = normalize(lightPos - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
    float impact = max(dot(norm, lightDirection), 0.0);// Calculate diffuse impact by generating dot product of normal and light
    vec3 diffuse = impact * lightColor; // Generate diffuse light color

    //Calculate Specular lighting*/
    //key light intensity of 100%
    float specularIntensity = 1.0f; // Set specular light strength
    float highlightSize = 16.0f; // Set specular highlight size
    vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
    vec3 reflectDir = reflect(-lightDirection, norm);// Calculate reflection vector
    //Calculate specular component
    float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
    vec3 specular = specularIntensity * specularComponent * lightColor;

    // Texture holds the color to be used for all three components
    vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);

    // Calculate phong result
    vec3 phong = (ambient + diffuse + specular) * textureColor.xyz;




    //----------directional light calculations--------
    vec3 lightDir = normalize(-directionL);
    float diff = max(dot(norm, lightDir), 0.0);
    vec3 reflectDir2 = reflect(-lightDir, norm);
    float spec = pow(max(dot(viewDir, reflectDir2), 0.0), 1.0);
    //ambient strength 0.1f
    vec3 ambCalc = 0.6f * lightColor2;
    //directional light intensity of 10%
    float specIntensity = 0.7f;
    vec3 specCalc = spec * specIntensity * lightColor2;

    vec3 ambient2 = ambCalc * vec3(texture(uTexture, vertexTextureCoordinate));
    vec3 diffuse2 = diffuse * diff * vec3(texture(uTexture, vertexTextureCoordinate));
    vec3 specular2 = specCalc * vec3(texture(uTexture, vertexTextureCoordinate));
    vec3 result = ambient2 + diffuse2 + specular2;


    //combine point light and directional light for multiple lights 
    fragmentColor = vec4(phong + result, 1.0); // Send lighting results to GPU
}
);


/* Lamp Shader Source Code*/
const GLchar* lampVertexShaderSource = GLSL(440,

    layout(location = 0) in vec3 position; // VAP position 0 for vertex position data

        //Uniform / Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates
}
);


/* Fragment Shader Source Code*/
const GLchar* lampFragmentShaderSource = GLSL(440,

    out vec4 fragmentColor; // For outgoing lamp color (smaller cube) to the GPU

void main()
{
    fragmentColor = vec4(1.0f); // Set color to white (1.0f,1.0f,1.0f) with alpha 1.0
}
);



// Images are loaded with Y axis going down, but OpenGL's Y axis goes up, so let's flip it
void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
    for (int j = 0; j < height / 2; ++j)
    {
        int index1 = j * width * channels;
        int index2 = (height - 1 - j) * width * channels;

        for (int i = width * channels; i > 0; --i)
        {
            unsigned char tmp = image[index1];
            image[index1] = image[index2];
            image[index2] = tmp;
            ++index1;
            ++index2;
        }
    }
}

int main(int argc, char* argv[])
{
    if (!UInitialize(argc, argv, &gWindow))
        return EXIT_FAILURE;

    // Create the mesh
    UCreateMesh(gMesh); // Calls the function to create the Vertex Buffer Object

    // Create the shader programs
    if (!UCreateShaderProgram(cubeVertexShaderSource, cubeFragmentShaderSource, gCubeProgramId))
        return EXIT_FAILURE;

    if (!UCreateShaderProgram(lampVertexShaderSource, lampFragmentShaderSource, gLampProgramId))
        return EXIT_FAILURE;

    // Load texture
    const char* texFilename = "couch-arms.jpg";
    if (!UCreateTexture(texFilename, gTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(gCubeProgramId);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(gCubeProgramId, "uTexture"), 0);

    // Load texture 2
    const char* texFilename2 = "brown.jpg";
    if (!UCreateTexture(texFilename2, gTextureId2))
    {
        cout << "Failed to load texture " << texFilename2 << endl;
        return EXIT_FAILURE;
    }


    // Load texture 3
    const char* texFilename3 = "arms.jpg";
    if (!UCreateTexture(texFilename3, gTextureId3))
    {
        cout << "Failed to load texture " << texFilename3 << endl;
        return EXIT_FAILURE;
    }


    // Load texture 4
    const char* texFilename4 = "floor.jpg";
    if (!UCreateTexture(texFilename4, gTextureId4))
    {
        cout << "Failed to load texture " << texFilename4 << endl;
        return EXIT_FAILURE;
    }


    // Sets the background color of the window to black (it will be implicitely used by glClear)
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    // render loop
    // -----------
    while (!glfwWindowShouldClose(gWindow))
    {
        // per-frame timing
        // --------------------
        float currentFrame = glfwGetTime();
        gDeltaTime = currentFrame - gLastFrame;
        gLastFrame = currentFrame;
        // input
        // -----
        UProcessInput(gWindow);

        // Render this frame
        URender();

        glfwPollEvents();
    }

    // Release mesh data
    UDestroyMesh(gMesh);

    // Release texture
    UDestroyTexture(gTextureId);
    // Release texture
    UDestroyTexture(gTextureId2);
    // Release texture
    UDestroyTexture(gTextureId3);
    // Release texture
    UDestroyTexture(gTextureId4);
    // Release shader programs
    UDestroyShaderProgram(gCubeProgramId);
    UDestroyShaderProgram(gLampProgramId);

    exit(EXIT_SUCCESS); // Terminates the program successfully
}


// Initialize GLFW, GLEW, and create a window
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
    // GLFW: initialize and configure
    // ------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // GLFW: window creation
    // ---------------------
    * window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
    if (*window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return false;
    }
    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);
    glfwSetCursorPosCallback(*window, UMousePositionCallback);
    glfwSetScrollCallback(*window, UMouseScrollCallback);
    glfwSetMouseButtonCallback(*window, UMouseButtonCallback);
    glfwSetKeyCallback(*window, key_callback);
    // tell GLFW to capture our mouse
    glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // GLEW: initialize
    // ----------------
    // Note: if using GLEW version 1.13 or earlier
    glewExperimental = GL_TRUE;
    GLenum GlewInitResult = glewInit();

    if (GLEW_OK != GlewInitResult)
    {
        std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
        return false;
    }

    // Displays GPU OpenGL version
    cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;

    return true;
}


// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
void UProcessInput(GLFWwindow* window)
{
    static const float cameraSpeed = 2.5f;

    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        gCamera.ProcessKeyboard(LEFT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        gCamera.ProcessKeyboard(RIGHT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        gCamera.ProcessKeyboard(UP, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        gCamera.ProcessKeyboard(DOWN, gDeltaTime);
}


// glfw: whenever the window size changed (by OS or user resize) this callback function executes
void UResizeWindow(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}

// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
    if (gFirstMouse)
    {
        gLastX = xpos;
        gLastY = ypos;
        gFirstMouse = false;
    }

    float xoffset = xpos - gLastX;
    float yoffset = gLastY - ypos; // reversed since y-coordinates go from bottom to top

    gLastX = xpos;
    gLastY = ypos;

    gCamera.ProcessMouseMovement(xoffset, yoffset);
}

// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
    gCamera.ProcessMouseScroll(yoffset);
}

//glfw: whenever p is pressed, this callback is called. handles single key events, change back and forth from perspective to orthographic projection
void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_P && action == GLFW_PRESS)
    {
        if (perspective)
            perspective = false;
        else
            perspective = true;
    }
}

// glfw: handle mouse button events
// --------------------------------
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
    switch (button)
    {
    case GLFW_MOUSE_BUTTON_LEFT:
    {
        if (action == GLFW_PRESS)
            cout << "Left mouse button pressed" << endl;
        else
            cout << "Left mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_MIDDLE:
    {
        if (action == GLFW_PRESS)
            cout << "Middle mouse button pressed" << endl;
        else
            cout << "Middle mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_RIGHT:
    {
        if (action == GLFW_PRESS)
            cout << "Right mouse button pressed" << endl;
        else
            cout << "Right mouse button released" << endl;
    }
    break;

    default:
        cout << "Unhandled mouse button event" << endl;
        break;
    }
}


// Functioned called to render a frame
void URender()
{
    // Enable z-depth
    glEnable(GL_DEPTH_TEST);

    // Clear the frame and z buffers
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // 1. Scales the object by 1
    glm::mat4 scale = glm::scale(glm::vec3(1.0f, 1.0f, 1.0f));
    // 2. Rotates object by 30 degrees on x axis
    glm::mat4 rotation = glm::rotate(30.0f, glm::vec3(1.0f, 0.0f, 0.0f));
    // 3. Place scene in front of camera
    glm::mat4 translation = glm::translate(glm::vec3(-1.0f, 0.0f, -7.0f));
    // Model matrix: transformations are applied right-to-left order
    glm::mat4 model = translation * rotation * scale;

    // camera/view transformation
    glm::mat4 view = gCamera.GetViewMatrix();


    // Creates a perspective or ortho projection based on key press
    glm::mat4 projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    if (perspective) {
        glm::mat4 projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
        // Set the shader to be used
        glUseProgram(gCubeProgramId);

        // Retrieves and passes transform matrices to the Shader program
        modelLoc = glGetUniformLocation(gCubeProgramId, "model");
        viewLoc = glGetUniformLocation(gCubeProgramId, "view");
        projLoc = glGetUniformLocation(gCubeProgramId, "projection");

        glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
        glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));
    }
    if (!perspective) {
        glm::mat4 projection = glm::ortho(-5.0f, 5.0f, -5.0f, 5.0f, 0.1f, 100.0f);
        // Set the shader to be used
        glUseProgram(gCubeProgramId);

        // Retrieves and passes transform matrices to the Shader program
        modelLoc = glGetUniformLocation(gCubeProgramId, "model");
        viewLoc = glGetUniformLocation(gCubeProgramId, "view");
        projLoc = glGetUniformLocation(gCubeProgramId, "projection");

        glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
        glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));
    }


    // Reference matrix uniforms from the Cube Shader program for the object color, light color, light position, and camera position

   //point light uniforms
    GLint objectColorLoc = glGetUniformLocation(gCubeProgramId, "objectColor");
    GLint lightColorLoc = glGetUniformLocation(gCubeProgramId, "lightColor");
    GLint lightPositionLoc = glGetUniformLocation(gCubeProgramId, "lightPos");
    GLint viewPositionLoc = glGetUniformLocation(gCubeProgramId, "viewPosition");

    //directional light uniforms
    GLint dirLoc = glGetUniformLocation(gCubeProgramId, "directionL");
    GLint lightColorLoc2 = glGetUniformLocation(gCubeProgramId, "lightColor2");

    // Pass color, light, and camera data to the Cube Shader program's corresponding uniforms point light
    glUniform3f(objectColorLoc, gObjectColor.r, gObjectColor.g, gObjectColor.b);
    glUniform3f(lightColorLoc, gLightColor.r, gLightColor.g, gLightColor.b);
    glUniform3f(lightPositionLoc, gLightPosition.x, gLightPosition.y, gLightPosition.z);

    //pass directional light uniforms
    glUniform3f(dirLoc, direction.x, direction.y, direction.z);
    glUniform3f(lightColorLoc2, gLightColor2.r, gLightColor2.g, gLightColor2.b);

    const glm::vec3 cameraPosition = gCamera.Position;
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

    GLint UVScaleLoc = glGetUniformLocation(gCubeProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    //draw mirrors and pillows
    // Activate the VBOs contained within the mesh's VAO, this determines which object is rendered first
    glBindVertexArray(gMesh.vao);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureId2);
    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gMesh.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle


    //draw couch top and base
    glBindVertexArray(gMesh.vao2);
    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureId);
    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gMesh.nIndicesC, GL_UNSIGNED_SHORT, NULL); // Draws the triangle


    //draw couch armrests
    glBindVertexArray(gMesh.vao3);
    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureId3);
    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gMesh.nIndicesA, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

    //draw floor and wall
    glBindVertexArray(gMesh.vao4);
    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureId4);
    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gMesh.nIndicesF, GL_UNSIGNED_SHORT, NULL); // Draws the triangle


    // LAMP: draw lamp to show point light location
    //----------------
    glUseProgram(gLampProgramId);

    //Transform the smaller object used as a visual que for the light source
    model = glm::translate(gLightPosition) * glm::scale(gLightScale);

    // Reference matrix uniforms from the Lamp Shader program
    modelLoc = glGetUniformLocation(gLampProgramId, "model");
    viewLoc = glGetUniformLocation(gLampProgramId, "view");
    projLoc = glGetUniformLocation(gLampProgramId, "projection");

    // Pass matrix data to the Lamp Shader program's matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));
    glDrawElements(GL_TRIANGLES, gMesh.nIndicesF, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

    glBindVertexArray(0);

    // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
    glfwSwapBuffers(gWindow);    // Flips the the back buffer with the front buffer every frame.
}




// Implements the UCreateMesh function
void UCreateMesh(GLMesh& mesh)
{
    // Position, norms, and texture data
    GLfloat vertsFloor[] = {
        //planes for scene base
             //---------------------
             //floor plane
             3.0f,  3.5f, -1.01f,   0.0f,  1.0f,  0.0f,   1.0f, 1.0f, // Top Right Vertex 0
             3.0f, -3.5f, -1.01f,   1.0f, 0.0f,  0.0f,    1.0f, 0.0f,  // Bottom Right Vertex 1
            -1.6f, -3.5f, -1.01f,   0.0f,  -1.0f,  0.0f,  0.0f, 0.0f,  // Bottom Left Vertex 2
            -1.6f,  3.5f, -1.01f,   -1.0f,  0.0f,  0.0f,  0.0f, 1.0f, // Top Left Vertex 3

            //back plane
            -1.6f,  3.5f, 3.51f,   0.0f,  1.0f,  0.0f,    1.0f, 1.0f, // Top Right Vertex 4
            -1.6f, -3.5f, 3.51f,   0.0f,  0.0f,  1.0f,    0.0f, 1.0f,  // tl Vertex 5
            -1.6f, -3.5f, -1.01f,  0.0f,  -1.0f,  0.0f,   1.0f, 0.0f, // Bottom Left Vertex 6
            -1.6f,  3.5f, -1.01f,  0.0f,  0.0f,  -1.0f,   0.0f, 0.0f,  // br Vertex 7
    };
    GLushort indicesFloor[] = {
        //planes for scene base
            //---------------------
            //floor plane
            0, 1, 3, // Triangle 76
            1, 2, 3, // Triangle 77

            //back plane
            4, 5, 7, // Triangle 78
            5, 6, 7, // Triangle 79

    };

    GLfloat vertsCouch[] = {
        // Vertex Positions x, y, z  //normals   // texture coords (r,g,b,a)

        //couch, complex object consisting of 4 cubes
        //-------------------------------------------
        //cube 1 couch base 
         1.5f,  2.5f, 0.0f,     0.0f,  1.0f,  0.0f,     2.0f, 2.0f, // Top Right Vertex 0
         1.5f, -2.5f, 0.0f,     1.0f, 0.0f,  0.0f,     2.0f, 0.0f, // Bottom Right Vertex 1
        -0.5f, -2.5f, 0.0f,     0.0f,  -1.0f,  0.0f,    0.0f, 0.0f, // Bottom Left Vertex 2
        -0.5f,  2.5f, 0.0f,     -1.0f,  0.0f,  0.0f,     0.0f, 2.0f, // Top Left Vertex 3

         1.5f, -2.5f, -1.0f,    1.0f,  0.0f,  0.0f,     2.0f, 0.0f, // 4 br  right
         1.5f,  2.5f, -1.0f,    0.0f,  1.0f,  0.0f,     2.0f, 2.0f, //  5 tl  right
        -0.5f,  2.5f, -1.0f,    -1.0f,  0.0f,  0.0f,    0.0f, 2.0f, //  6 tl  top
        -0.5f, -2.5f, -1.0f,    0.0f,  0.0f, -1.0f,     0.0f, 0.0f,  //  7 bl back


        //cube 2 couch top
         -0.5f,  3.0f, 1.5f,    0.0f,  1.0f,  0.0f,    1.0f, 1.0f, // Top Right Vertex 8 o
         -0.5f, -3.0f, 1.5f,    1.0f,  0.0f,  0.0f,    1.0f, 0.0f, // Bottom Right Vertex 9 
        -1.5f, -3.0f, 1.5f,     0.0f,  -1.0f,  0.0f,    0.0f, 0.0f, // Bottom Left Vertex 10 
        -1.5f,  3.0f, 1.5f,     -1.0f,  0.0f,  0.0f,    0.0f, 1.0f, // Top Left Vertex 11 

         -0.5f, -3.0f, -1.0f,   0.0f,  -1.0f,  0.0f,    1.0f, 0.0f, // 12 br  right
         -0.5f,  3.0f, -1.0f,   1.0f,  0.0f,  0.0f,    1.0f, 1.0f, //  13 tl  right
        -1.5f,  3.0f, -1.0f,    -1.0f,  0.0f,  0.0f,    0.0f, 1.0f, //  14 tl  top
        -1.5f, -3.0f, -1.0f,    0.0f,  0.0f,  -1.0f,    0.0f, 0.0f,  //  15 bl back

        //extra couch base face
         1.5f, -2.5f, 0.0f,     0.0f,  0.0f,  1.0f,    2.0f, 2.0f, // top left 15
         1.5f,  2.5f, 0.0f,     0.0f,  1.0f,  0.0f,    0.0f, 2.0f, //  top right 17
         1.5f, -2.5f, -1.0f,    0.0f,  -1.0f,  0.0f,   2.0f, 0.0f, //  bottom left 18
         1.5f,  2.5f, -1.0f,    0.0f,  0.0f,  -1.0f,   0.0f, 0.0f, //  bottom right 19

         //extra couch top front face
         -0.5f, -3.0f, -1.0f,   0.0f,  -1.0f,  0.0f,    0.0f, 0.0f, // 20
         -0.5f,  3.0f, -1.0f,   0.0f,  0.0f,  -1.0f,    2.0f, 0.0f, //  21
         -0.5f,  3.0f, 1.5f,    0.0f,  1.0f,  0.0f,    2.0f, 2.0f, // 22
         -0.5f, -3.0f, 1.5f,    0.0f,  0.0f,  1.0f,    0.0f, 2.0f, // 23

         //couch top side face
        -0.5f, -3.0f, 1.5f,    1.0f,  0.0f,  0.0f,    1.0f, 1.0f, // Bottom Right Vertex 24
        -1.5f, -3.0f, 1.5f,     0.0f,  -1.0f,  0.0f,    0.0f, 1.0f, // Bottom Left Vertex 25 
        -1.5f, -3.0f, -1.0f,    0.0f,  0.0f,  -1.0f,    0.0f, 0.0f,  //  15 bl back 26
        -0.5f, -3.0f, -1.0f,   0.0f,  -1.0f,  0.0f,    1.0f, 0.0f, // 12 br  right 27

        //other side 
        -0.5f, 3.0f, 1.5f,    0.0f,  0.0f,  0.0f,    1.0f, 1.0f, // Bottom Right Vertex 28
        -1.5f, 3.0f, 1.5f,     0.0f,  0.0f,  0.0f,    0.0f, 1.0f, // Bottom Left Vertex 29 
        -1.5f, 3.0f, -1.0f,    0.0f,  0.0f,  0.0f,    0.0f, 0.0f,  //  15 bl back 30
        -0.5f, 3.0f, -1.0f,   0.0f,  0.0f,  0.0f,    1.0f, 0.0f, // 12 br  right 31
    };
    GLushort indicesCouch[] = {
        //triangles to form complex objects
        //---------------------------------

        //couch
        //-----
        //cube 1, couch base
        0, 1, 3,  // Triangle 1
        1, 2, 3,   // Triangle 2
        0, 5, 6, // Triangle 5
        0, 3, 6,  // Triangle 6
        4, 5, 6, // Triangle 7
        4, 6, 7, // Triangle 8
        2, 3, 6, // Triangle 9
        2, 6, 7, // Triangle 10
        1, 4, 7, // Triangle 11
        1, 2, 7, // Triangle 12
        16, 18, 19,
        17, 19, 16,

        //cube 2, couch top
        26, 27, 24,
        26, 25, 24,
        30, 31, 28,
        30, 29, 28,
        8, 9, 11, // Triangle 13
        9, 10, 11, // Triangle 14
        12, 13, 14, // Triangle 19
        12, 14, 15, // Triangle 20
        10, 11, 14, // Triangle 21
        10, 14, 15, // Triangle 22


        20, 21, 22,
        20, 23, 22,
    };
    GLfloat vertsArms[] = {
        //cube 3 right armrest
        1.5f,  3.0f, 0.5f,      0.0f,  0.0f,  0.0f,     1.0f, 1.0f, // Top Right Vertex 0
         1.5f, 2.5f, 0.5f,      0.0f, 0.0f,  0.0f,   1.0f, 0.0f, // Bottom Right Vertex 1
        -0.5f, 2.5f, 0.5f,      0.0f,  0.0f,  0.0f,   0.0f, 0.0f,  // Bottom Left Vertex 2
        -0.5f,  3.0f, 0.5f,     0.0f,  0.0f,  0.0f,    0.0f, 1.0f, // Top Left Vertex 3

         1.5f, 2.5f, -1.0f,     0.0f, 0.0f,  0.0f,     1.0f, 0.0f, // 20 br  right 4
         1.5f,  3.0f, -1.0f,    0.0f,  0.0f,  0.0f,    1.0f, 1.0f, //  21 tl  right 5
        -0.5f,  3.0f, -1.0f,    0.0f, 0.0f,  0.0f,    0.0f, 1.0f,  //  22 tl  top 6
        -0.5f, 2.5f, -1.0f,     0.0f,  0.0f,  0.0f,    0.0f, 0.0f,   //  23 bl back 7


        //cube 4 left armrest
        1.5f,  -3.0f, 0.5f,     0.0f, -1.0f,  0.0f,    1.0f, 1.0f,  // Top Right Vertex 24 8
         1.5f, -2.5f, 0.5f,     1.0f,  0.0f,  0.0f,    1.0f, 0.0f, // Bottom Right Vertex 25 9
        -0.5f, -2.5f, 0.5f,     -1.0f,  0.0f,  0.0f,   0.0f, 0.0f, // Bottom Left Vertex 26 10
        -0.5f,  -3.0f, 0.5f,    0.0f,  0.0f,  1.0f,    0.0f, 1.0f, // Top Left Vertex 27 11

         1.5f, -2.5f, -1.0f,    1.0f,  0.0f,  0.0f,   1.0f, 0.0f,  // 28 br  right 12
         1.5f,  -3.0f, -1.0f,   0.0f, -1.0f,  0.0f,   1.0f, 1.0f,  //  29 tl  right 13
        -0.5f,  -3.0f, -1.0f,  -1.0f,  0.0f,  0.0f,   0.0f, 1.0f,  //  30 tl  top 14
        -0.5f, -2.5f, -1.0f,    0.0f, 1.0f,  0.0f,   0.0f, 0.0f,   //  31 bl back 15


        1.5f,  -3.0f, -1.0f,    0.0f,  1.0f,  0.0f,     1.0f, 0.0f,  //  29 tl  right 16 
        -0.5f,  -3.0f, -1.0f,   -1.0f,  0.0f,  0.0f,   0.0f, 0.0f,  //  30 tl  top 17
        -0.5f,  -3.0f, 0.5f,    0.0f,  0.0f,  1.0f,   0.0f, 1.0f, // Top Left Vertex 27 18
        1.5f,  -3.0f, 0.5f,     1.0f,  0.0f,  0.0f,     1.0f, 1.0f,  // Top Right Vertex 24 19

        //right armrest extra face
        1.5f,  3.0f, -1.0f,     0.0f,  0.0f,  0.0f,   1.0f, 0.0f,  //  29 tl  right 20
        -0.5f,  3.0f, -1.0f,    0.0f,  0.0f,  0.0f,   0.0f, 0.0f,  //  30 tl  top 21
        -0.5f,  3.0f, 0.5f,     0.0f,  0.0f,  0.0f,    0.0f, 1.0f, // Top Left Vertex 27 22
        1.5f,  3.0f, 0.5f,      0.0f,  0.0f,  0.0f,    1.0f, 1.0f,  // Top Right Vertex 24 23

        //left armrest extra face
         1.5f, -2.5f, -1.0f,    1.0f,  0.0f,  0.0f,   1.0f, 0.0f,  // 24
         1.5f,  -3.0f, -1.0f,   0.0f, -1.0f,  0.0f,   0.0f, 0.0f,  //  25
         1.5f,  -3.0f, 0.5f,     0.0f, -1.0f,  0.0f,    0.0f, 1.0f,  // 26
         1.5f, -2.5f, 0.5f,     1.0f,  0.0f,  0.0f,    1.0f, 1.0f, // 27

    };
    // Index data to share position data
    GLushort indicesArms[] = {
        0, 1, 3,  // Triangle 1
        1, 2, 3,   // Triangle 2
        0, 1, 4,  // Triangle 3
        0, 4, 5,  // Triangle 4
        4, 5, 6, // Triangle 7
        4, 6, 7, // Triangle 8
        2, 3, 6, // Triangle 9
        2, 6, 7, // Triangle 10
        1, 4, 7, // Triangle 11
        1, 2, 7, // Triangle 12
        25, 24, 27,
        25, 26, 27,

        //cube 2,
        8, 9, 11, // Triangle 13
        9, 10, 11, // Triangle 14
        12, 13, 14, // Triangle 19
        12, 14, 15, // Triangle 20
        10, 11, 14, // Triangle 21
        10, 14, 15, // Triangle 22
        9, 12, 15, // Triangle 23
        9, 10, 15, // Triangle 24
        16, 17, 18,
        16, 19, 18,
        20, 21, 22,
        20, 23, 22,
    };

    GLfloat verts[] = {
        // Vertex Positions x, y, z   // Colors (r,g,b,a)

        //couch, complex object consisting of 4 cubes
        //-------------------------------------------
        //cube 1 couch base
         1.5f,  2.5f, 0.0f,   1.0f, 0.0f, 0.0f, 1.0f, // Top Right Vertex 0
         1.5f, -2.5f, 0.0f,   0.0f, 1.0f, 0.0f, 1.0f, // Bottom Right Vertex 1
        -0.5f, -2.5f, 0.0f,   0.0f, 0.0f, 1.0f, 1.0f, // Bottom Left Vertex 2
        -0.5f,  2.5f, 0.0f,   1.0f, 0.0f, 1.0f, 1.0f, // Top Left Vertex 3

         1.5f, -2.5f, -1.0f,  0.5f, 0.5f, 1.0f, 1.0f, // 4 br  right
         1.5f,  2.5f, -1.0f,  1.0f, 1.0f, 0.5f, 1.0f, //  5 tl  right
        -0.5f,  2.5f, -1.0f,  0.2f, 0.2f, 0.5f, 1.0f, //  6 tl  top
        -0.5f, -2.5f, -1.0f,  1.0f, 0.0f, 1.0f, 1.0f,  //  7 bl back


        //cube 2 couch top
         -0.5f,  3.0f, 1.5f,   1.0f, 0.0f, 0.0f, 1.0f, // Top Right Vertex 8 o
         -0.5f, -3.0f, 1.5f,   0.0f, 1.0f, 0.0f, 1.0f, // Bottom Right Vertex 9 
        -1.5f, -3.0f, 1.5f,   0.0f, 0.0f, 1.0f, 1.0f, // Bottom Left Vertex 10 
        -1.5f,  3.0f, 1.5f,   1.0f, 0.0f, 1.0f, 1.0f, // Top Left Vertex 11 

         -0.5f, -3.0f, -1.0f,  0.5f, 0.5f, 1.0f, 1.0f, // 12 br  right
         -0.5f,  3.0f, -1.0f,  1.0f, 1.0f, 0.5f, 1.0f, //  13 tl  right
        -1.5f,  3.0f, -1.0f,  0.2f, 0.2f, 0.5f, 1.0f, //  14 tl  top
        -1.5f, -3.0f, -1.0f,  1.0f, 0.0f, 1.0f, 1.0f,  //  15 bl back

        //cube 3 right armrest
        1.5f,  3.0f, 0.5f,   1.0f, 0.0f, 0.0f, 1.0f, // Top Right Vertex 16
         1.5f, 2.5f, 0.5f,   0.0f, 1.0f, 0.0f, 1.0f, // Bottom Right Vertex 17
        -0.5f, 2.5f, 0.5f,   0.0f, 0.0f, 1.0f, 1.0f, // Bottom Left Vertex 18
        -0.5f,  3.0f, 0.5f,   1.0f, 0.0f, 1.0f, 1.0f, // Top Left Vertex 19

         1.5f, 2.5f, -1.0f,  0.5f, 0.5f, 1.0f, 1.0f, // 20 br  right
         1.5f,  3.0f, -1.0f,  1.0f, 1.0f, 0.5f, 1.0f, //  21 tl  right
        -0.5f,  3.0f, -1.0f,  0.2f, 0.2f, 0.5f, 1.0f, //  22 tl  top
        -0.5f, 2.5f, -1.0f,  1.0f, 0.0f, 1.0f, 1.0f,  //  23 bl back

        //cube 4 left armrest
        1.5f,  -3.0f, 0.5f,   1.0f, 0.0f, 0.0f, 1.0f, // Top Right Vertex 24
         1.5f, -2.5f, 0.5f,   0.0f, 1.0f, 0.0f, 1.0f, // Bottom Right Vertex 25
        -0.5f, -2.5f, 0.5f,   0.0f, 0.0f, 1.0f, 1.0f, // Bottom Left Vertex 26
        -0.5f,  -3.0f, 0.5f,   1.0f, 0.0f, 1.0f, 1.0f, // Top Left Vertex 27

         1.5f, -2.5f, -1.0f,  0.5f, 0.5f, 1.0f, 1.0f, // 28 br  right
         1.5f,  -3.0f, -1.0f,  1.0f, 1.0f, 0.5f, 1.0f, //  29 tl  right
        -0.5f,  -3.0f, -1.0f,  0.2f, 0.2f, 0.5f, 1.0f, //  30 tl  top
        -0.5f, -2.5f, -1.0f,  1.0f, 0.0f, 1.0f, 1.0f,  //  31 bl back


        //pillows
        //-------
        //pyramid 1 middle pillow
         0.25f,  0.8f, 0.0f,   1.0f, 0.0f, 0.0f, 1.0f, // Top Right Vertex 32
         0.25f, -0.8f, 0.0f,   0.0f, 1.0f, 0.0f, 1.0f, // Bottom Right Vertex 33
        -0.25f, -0.8f, 0.0f,   0.0f, 0.0f, 1.0f, 1.0f, // Bottom Left Vertex 34
        -0.25f,  0.8f, 0.0f,   1.0f, 0.0f, 1.0f, 1.0f, // Top Left Vertex 35

         0.125f, -0.8f, 0.75f,  0.5f, 0.5f, 1.0f, 1.0f, // 36 br  right
         0.125f,  0.8f, 0.75f,  1.0f, 1.0f, 0.5f, 1.0f, //  37 tl  left

         //pyramid 2 right pillow
         0.25f,  2.5f, 0.0f,   1.0f, 0.0f, 0.0f, 1.0f, // Top Right Vertex 38
         0.25f, 1.0f, 0.0f,   0.0f, 1.0f, 0.0f, 1.0f, // Bottom Right Vertex 39
        -0.25f, 1.0f, 0.0f,   0.0f, 0.0f, 1.0f, 1.0f, // Bottom Left Vertex 40
        -0.25f,  2.5f, 0.0f,   1.0f, 0.0f, 1.0f, 1.0f, // Top Left Vertex 41

         0.125f, 1.0f, 1.25f,  0.5f, 0.5f, 1.0f, 1.0f, // 42 br  right
         0.125f,  2.5f, 1.25f,  1.0f, 1.0f, 0.5f, 1.0f, //  43 tl  left

         //pyramid 2 left pillow
         0.25f,  -2.5f, 0.0f,   1.0f, 0.0f, 0.0f, 1.0f, // Top Right Vertex 44
         0.25f, -1.0f, 0.0f,   0.0f, 1.0f, 0.0f, 1.0f, // Bottom Right Vertex 45
        -0.25f, -1.0f, 0.0f,   0.0f, 0.0f, 1.0f, 1.0f, // Bottom Left Vertex 46
        -0.25f,  -2.5f, 0.0f,   1.0f, 0.0f, 1.0f, 1.0f, // Top Left Vertex 47

         0.125f, -1.0f, 1.25f,  0.5f, 0.5f, 1.0f, 1.0f, // 48 br  right
         0.125f,  -2.5f, 1.25f,  1.0f, 1.0f, 0.5f, 1.0f, //  49 tl  left


         //planes for scene base
         //---------------------
         //floor plane
         3.0f,  3.5f, -1.01f,   1.0f, 0.0f, 0.0f, 1.0f, // Top Right Vertex 50
         3.0f, -3.5f, -1.01f,   0.0f, 1.0f, 0.0f, 1.0f, // Bottom Right Vertex 51
        -1.6f, -3.5f, -1.01f,   0.0f, 0.0f, 1.0f, 1.0f, // Bottom Left Vertex 52
        -1.6f,  3.5f, -1.01f,   1.0f, 0.0f, 1.0f, 1.0f, // Top Left Vertex 53

        //back plane
        -1.6f,  3.5f, 3.51f,   1.0f, 0.0f, 0.0f, 1.0f, // Top Right Vertex 54
        -1.6f, -3.5f, 3.51f,   0.0f, 1.0f, 0.0f, 1.0f, // Bottom Right Vertex 55
        -1.6f, -3.5f, -1.01f,   0.0f, 0.0f, 1.0f, 1.0f, // Bottom Left Vertex 56
        -1.6f,  3.5f, -1.01f,   1.0f, 0.0f, 1.0f, 1.0f, // Top Left Vertex 57


        //mirror 1, complex object consisting of cylinder and plane
        //---------------------------------------------------------
        //back of cylinder 1 face
        -1.59f,  0.5f, 3.0f,   1.0f, 0.0f, 0.0f, 1.0f, // Top right Vertex 58
        -1.59f, 0.0f, 3.0f,   0.0f, 1.0f, 0.0f, 1.0f, // top left vertex 59
        -1.59f, 0.25f, 2.5f,   0.0f, 0.0f, 1.0f, 1.0f, // Center of cylinder 60
        -1.59f, 0.75f, 2.7f,    1.0f, 0.0f, 1.0f, 1.0f, //  right vertex 61
        -1.59f, 0.75f, 2.25f,    1.0f, 0.0f, 1.0f, 1.0f, //  right rect bottom vertex 62
        -1.59f, 0.5f, 2.0f,    1.0f, 1.0f, 0.5f, 1.0f, //  bottom right  vertex 63
        -1.59f, 0.0f, 2.0f,   0.0f, 1.0f, 0.0f, 1.0f, // bottom left vertex 64
        -1.59f, -0.25f, 2.25f,    1.0f, 0.0f, 1.0f, 1.0f, //  left rect bottom vertex 65
        -1.59f, -0.25f, 2.7f,    1.0f, 0.0f, 1.0f, 1.0f, //  left vertex 66

        //front of cylinder 1 face
        -1.5f,  0.5f, 3.0f,   1.0f, 0.0f, 0.0f, 1.0f, // Top right Vertex 67
         -1.5f, 0.0f, 3.0f,   0.0f, 1.0f, 0.0f, 1.0f, // top left vertex 68
        -1.5f, 0.25f, 2.5f,   0.0f, 0.0f, 1.0f, 1.0f, // Center of cylinder 69
        -1.5f, 0.75f, 2.7f,    1.0f, 0.0f, 1.0f, 1.0f, //  right vertex 70
        -1.5f, 0.75f, 2.25f,    1.0f, 0.0f, 1.0f, 1.0f, //  right rect bottom vertex 71
        -1.5f, 0.5f, 2.0f,    1.0f, 1.0f, 0.5f, 1.0f, //  bottom right  vertex 72
        -1.5f, 0.0f, 2.0f,   0.0f, 1.0f, 0.0f, 1.0f, // bottom left vertex 73
        -1.5f, -0.25f, 2.25f,    1.0f, 0.0f, 1.0f, 1.0f, //  left rect bottom vertex 74
        -1.5f, -0.25f, 2.7f,    1.0f, 0.0f, 1.0f, 1.0f, //  left vertex 75

        //inner plane 1, light blue
        -1.49f,  0.375f, 2.75f,   0.0f, 1.0f, 1.0f, 0.0f, // Top right Vertex 76
         -1.49f, 0.125f, 2.75f,   0.0f, 1.0f, 1.0f, 0.0f, // top left vertex 77
        -1.49f, 0.25f, 2.5f,   0.0f, 1.0f, 1.0f, 0.0f, // Center of cylinder 78
        -1.49f, 0.5f, 2.6f,   0.0f, 1.0f, 1.0f, 0.0f, //  right vertex 79
        -1.49f, 0.5f, 2.4f,  0.0f, 1.0f, 1.0f, 0.0f, //  right rect bottom vertex 80
        -1.49f, 0.375f, 2.25f,    0.0f, 1.0f, 1.0f, 0.0f, //  bottom right  vertex 81
        -1.49f, 0.125f, 2.25f,    0.0f, 1.0f, 1.0f, 0.0f, // bottom left vertex 82
        -1.49f, 0.0f, 2.4f, 0.0f, 1.0f, 1.0f, 0.0f, //  left rect bottom vertex 83
        -1.49f, 0.0f, 2.6f,  0.0f, 1.0f, 1.0f, 0.0f, //  left vertex 84


        //mirror 2, complex object consisting of cylinder and plane
        //---------------------------------------------------------
        //back of cylinder 2 face
        -1.59f,  2.5f, 3.0f,   1.0f, 0.0f, 0.0f, 1.0f, // Top right Vertex 85
        -1.59f, 2.0f, 3.0f,   0.0f, 1.0f, 0.0f, 1.0f, // top left vertex 86
        -1.59f, 2.25f, 2.5f,   0.0f, 0.0f, 1.0f, 1.0f, // Center of cylinder 87
        -1.59f, 2.75f, 2.7f,    1.0f, 0.0f, 1.0f, 1.0f, //  right vertex 88
        -1.59f, 2.75f, 2.25f,    1.0f, 0.0f, 1.0f, 1.0f, //  right rect bottom vertex 89
        -1.59f, 2.5f, 2.0f,    1.0f, 1.0f, 0.5f, 1.0f, //  bottom right  vertex 90
        -1.59f, 2.0f, 2.0f,   0.0f, 1.0f, 0.0f, 1.0f, // bottom left vertex 91
        -1.59f, 1.75f, 2.25f,    1.0f, 0.0f, 1.0f, 1.0f, //  left rect bottom vertex 92
        -1.59f, 1.75f, 2.7f,    1.0f, 0.0f, 1.0f, 1.0f, //  left vertex 93

        //front of cylinder 2 face
        -1.5f,  2.5f, 3.0f,   1.0f, 0.0f, 0.0f, 1.0f, // Top right Vertex 94
        -1.5f, 2.0f, 3.0f,   0.0f, 1.0f, 0.0f, 1.0f, // top left vertex 95
        -1.5f, 2.25f, 2.5f,   0.0f, 0.0f, 1.0f, 1.0f, // Center of cylinder 96
        -1.5f, 2.75f, 2.7f,    1.0f, 0.0f, 1.0f, 1.0f, //  right vertex 97
        -1.5f, 2.75f, 2.25f,    1.0f, 0.0f, 1.0f, 1.0f, //  right rect bottom vertex 98
        -1.5f, 2.5f, 2.0f,    1.0f, 1.0f, 0.5f, 1.0f, //  bottom right  vertex 99
        -1.5f, 2.0f, 2.0f,   0.0f, 1.0f, 0.0f, 1.0f, // bottom left vertex 100
        -1.5f, 1.75f, 2.25f,    1.0f, 0.0f, 1.0f, 1.0f, //  left rect bottom vertex 101
        -1.5f, 1.75f, 2.7f,    1.0f, 0.0f, 1.0f, 1.0f, //  left vertex 102

        //inner plane 2, light blue
        -1.49f,  2.375f, 2.75f,   0.0f, 1.0f, 1.0f, 0.0f, // Top right Vertex 103
        -1.49f, 2.125f, 2.75f,   0.0f, 1.0f, 1.0f, 0.0f, // top left vertex 104
        -1.49f, 2.25f, 2.5f,   0.0f, 1.0f, 1.0f, 0.0f, // Center of cylinder 105
        -1.49f, 2.5f, 2.6f,   0.0f, 1.0f, 1.0f, 0.0f, //  right vertex 106
        -1.49f, 2.5f, 2.4f,  0.0f, 1.0f, 1.0f, 0.0f, //  right rect bottom vertex 107
        -1.49f, 2.375f, 2.25f,    0.0f, 1.0f, 1.0f, 0.0f, //  bottom right  vertex 108
        -1.49f, 2.125f, 2.25f,    0.0f, 1.0f, 1.0f, 0.0f, // bottom left vertex 109
        -1.49f, 2.0f, 2.4f, 0.0f, 1.0f, 1.0f, 0.0f, //  left rect bottom vertex 110
        -1.49f, 2.0f, 2.6f,  0.0f, 1.0f, 1.0f, 0.0f, //  left vertex 111

        //mirror 3, complex object consisting of cylinder and plane
        //---------------------------------------------------------
        //back of cylinder 3 face
        -1.59f,  -1.5f, 3.0f,   1.0f, 0.0f, 0.0f, 1.0f, // Top right Vertex 112
        -1.59f, -2.0f, 3.0f,   0.0f, 1.0f, 0.0f, 1.0f, // top left vertex 113
        -1.59f, -1.75f, 2.5f,   0.0f, 0.0f, 1.0f, 1.0f, // Center of cylinder 114
        -1.59f, -1.25f, 2.7f,    1.0f, 0.0f, 1.0f, 1.0f, //  right vertex 115
        -1.59f, -1.25f, 2.25f,    1.0f, 0.0f, 1.0f, 1.0f, //  right rect bottom vertex 116
        -1.59f, -1.5f, 2.0f,    1.0f, 1.0f, 0.5f, 1.0f, //  bottom right  vertex 117
        -1.59f, -2.0f, 2.0f,   0.0f, 1.0f, 0.0f, 1.0f, // bottom left vertex 118
        -1.59f, -2.25f, 2.25f,    1.0f, 0.0f, 1.0f, 1.0f, //  left rect bottom vertex 119
        -1.59f, -2.25f, 2.7f,    1.0f, 0.0f, 1.0f, 1.0f, //  left vertex 120

        //front of cylinder 3 face
        -1.5f,  -1.5f, 3.0f,   1.0f, 0.0f, 0.0f, 1.0f, // Top right Vertex 121
        -1.5f, -2.0f, 3.0f,   0.0f, 1.0f, 0.0f, 1.0f, // top left vertex 122
        -1.5f, -1.75f, 2.5f,   0.0f, 0.0f, 1.0f, 1.0f, // Center of cylinder 123
        -1.5f, -1.25f, 2.7f,    1.0f, 0.0f, 1.0f, 1.0f, //  right vertex 124
        -1.5f, -1.25f, 2.25f,    1.0f, 0.0f, 1.0f, 1.0f, //  right rect bottom vertex 125
        -1.5f, -1.5f, 2.0f,    1.0f, 1.0f, 0.5f, 1.0f, //  bottom right  vertex 126
        -1.5f, -2.0f, 2.0f,   0.0f, 1.0f, 0.0f, 1.0f, // bottom left vertex 127
        -1.5f, -2.25f, 2.25f,    1.0f, 0.0f, 1.0f, 1.0f, //  left rect bottom vertex 128
        -1.5f, -2.25f, 2.7f,    1.0f, 0.0f, 1.0f, 1.0f, //  left vertex 129

        //inner plane 3, light blue
        -1.49f,  -1.625f, 2.75f,   0.0f, 1.0f, 1.0f, 0.0f, // Top right Vertex 130
        -1.49f, -1.875f, 2.75f,   0.0f, 1.0f, 1.0f, 0.0f, // top left vertex 131
        -1.49f, -1.75f, 2.5f,   0.0f, 1.0f, 1.0f, 0.0f, // Center of cylinder 132
        -1.49f, -1.5f, 2.6f,   0.0f, 1.0f, 1.0f, 0.0f, //  right vertex 133
        -1.49f, -1.5f, 2.4f,  0.0f, 1.0f, 1.0f, 0.0f, //  right rect bottom vertex 134
        -1.49f, -1.625f, 2.25f,    0.0f, 1.0f, 1.0f, 0.0f, //  bottom right  vertex 135
        -1.49f, -1.875f, 2.25f,    0.0f, 1.0f, 1.0f, 0.0f, // bottom left vertex 136
        -1.49f, -2.0f, 2.4f, 0.0f, 1.0f, 1.0f, 0.0f, //  left rect bottom vertex 137
        -1.49f, -2.0f, 2.6f,  0.0f, 1.0f, 1.0f, 0.0f, //  left vertex 138
    };

    // Index data to share position data
    GLushort indices[] = {
        //pillows
        //-------
        //pyramid 1
        32, 33, 35, // Triangle 49
        33, 34, 35, // Triangle 50
        32, 33, 35, // Triangle 51
        33, 34, 36, // Triangle 52
        32, 35, 37, // Triangle 53
        36, 37, 35, // Triangle 54
        37, 35, 33, // Triangle 55
        36, 37, 33, // Triangle 56
        32, 33, 37, // Triangle 57
        34, 35, 36,

        //pyramid 2
        38, 39, 41, // Triangle 58
        39, 40, 41, // Triangle 59
        38, 39, 41, // Triangle 60
        39, 40, 42, // Triangle 61
        38, 41, 43, // Triangle 62
        42, 43, 41, // Triangle 63
        43, 41, 39, // Triangle 64
        42, 43, 39, // Triangle 65
        38, 39, 43, // Triangle 66
        40, 41, 42,

        //pyramid 3
        44, 45, 47, // Triangle 67
        45, 46, 47, // Triangle 68
        44, 45, 47, // Triangle 69
        45, 46, 48, // Triangle 70
        44, 47, 49, // Triangle 71
        48, 49, 47, // Triangle 72
        49, 47, 45, // Triangle 73
        48, 49, 45, // Triangle 74
        44, 45, 49, // Triangle 75
        46, 47, 48,

        //mirrors, complex shapes
        //-----------------------
        //mirror 1
        //cylinder 1, back face
        58, 59, 60,
        58, 60, 61,
        60, 61, 62,
        63, 62, 60,
        63, 64, 60,
        64, 65, 60,
        66, 65, 60,
        66, 59, 60,

        //cylinder 1, front face
        67, 68, 69,
        67, 69, 70,
        69, 70, 71,
        72, 71, 69,
        72, 73, 69,
        73, 74, 69,
        75, 74, 69,
        75, 68, 69,

        //cylinder 1, sides
        67, 58, 68,
        58, 59, 68,
        67, 58, 70,
        61, 62, 70,
        62, 71, 70,
        70, 58, 61,
        62, 63, 71,
        71, 63, 72,
        63, 72, 73,
        63, 73, 64,
        73, 74, 64,
        64, 65, 74,
        74, 65, 75,
        75, 65, 66,
        75, 66, 59,
        59, 75, 68,

        //inner plane 1
        76, 77, 78,
        76, 78, 79,
        78, 79, 80,
        81, 80, 78,
        81, 82, 78,
        82, 83, 78,
        84, 83, 78,
        84, 77, 78,


        //mirror 2
        //--------
        //cylinder 2, back face
         85, 86, 87,
         85, 87, 88,
         87, 88, 89,
         90, 89, 87,
         90, 91, 87,
         91, 92, 87,
         93, 92, 87,
         93, 86, 87,

         //cylinder 2, front face
          94, 95, 96,
          94, 96, 97,
          96, 97, 98,
          99, 98, 96,
          99, 100, 96,
          100, 101, 96,
          102, 101, 96,
          102, 95, 96,

          //cylinder 2 sides
          94, 85, 95,
          85, 86, 95,
          94, 85, 97,
          88, 89, 97,
          89, 98, 97,
          97, 85, 88,
          89, 90, 98,
          98, 90, 99,
          90, 99, 100,
          90, 100, 91,
          100, 101, 91,
          91, 92, 101,
          101, 92, 102,
          102, 92, 93,
          102, 93, 86,
          86, 102, 95,

          //inner plane 2
           103, 104, 105,
           103, 105, 106,
           105, 106, 107,
           108, 107, 105,
           108, 109, 105,
           109, 110, 105,
           111, 110, 105,
           111, 104, 105,


           //mirror 3
           //--------
           //cylinder 3, back face
            112, 113, 114,
            112, 114, 115,
            114, 115, 116,
            117, 116, 114,
            117, 118, 114,
            118, 119, 114,
            120, 119, 114,
            120, 113, 114,

            //cylinder 3 front face
             121, 122, 123,
             121, 123, 124,
             123, 124, 125,
             126, 125, 123,
             126, 127, 123,
             127, 128, 123,
             129, 128, 123,
             129, 122, 123,

             //cylinder 3 sides
             121, 112, 122,
             112, 113, 122,
             121, 112, 124,
             115, 116, 124,
             116, 125, 124,
             124, 112, 115,
             116, 117, 125,
             125, 117, 126,
             117, 126, 127,
             117, 127, 118,
             127, 128, 118,
             118, 119, 128,
             128, 119, 129,
             129, 119, 120,
             129, 120, 113,
             113, 129, 122,

             //inner plane 3
              130, 131, 132,
              130, 132, 133,
              132, 133, 134,
              135, 134, 132,
              135, 136, 132,
              136, 137, 132,
              138, 137, 132,
              138, 131, 132,
    };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerColor = 4;
    const GLuint floatsPerUV = 2;
    const GLuint floatsPerNormal = 3;


    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 8 buffers: pair first one for the vertex data; second one for the indices, for each set of objects
    glGenBuffers(8, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    mesh.nIndices = sizeof(indices) / sizeof(indices[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerColor);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(2, floatsPerColor, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(2);



    // COUCH BASE AND TOP VAO AND VBO
    glGenVertexArrays(1, &mesh.vao2); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao2);

    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[2]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertsCouch), vertsCouch, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    mesh.nIndicesC = sizeof(indicesCouch) / sizeof(indicesCouch[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[3]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indicesCouch), indicesCouch, GL_STATIC_DRAW);

    //stride between vertex position, normals and texture coords
    GLint strideN = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each
    

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, strideN, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, strideN, (void*)(sizeof(float)* floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, strideN, (void*)(sizeof(float)* (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);




    //COUCH ARMS VAO AND VBO
    glGenVertexArrays(1, &mesh.vao3); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao3);

    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[4]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertsArms), vertsArms, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    mesh.nIndicesA = sizeof(indicesArms) / sizeof(indicesArms[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[5]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indicesArms), indicesArms, GL_STATIC_DRAW);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, strideN, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, strideN, (void*)(sizeof(float)* floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, strideN, (void*)(sizeof(float)* (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);



    //FLOOR AND WALL VAO AND VBO
    glGenVertexArrays(1, &mesh.vao4); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao4);

    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[6]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertsFloor), vertsFloor, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    mesh.nIndicesF = sizeof(indicesFloor) / sizeof(indicesFloor[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[7]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indicesFloor), indicesFloor, GL_STATIC_DRAW);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, strideN, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, strideN, (void*)(sizeof(float)* floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, strideN, (void*)(sizeof(float)* (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}


void UDestroyMesh(GLMesh& mesh)
{
    glDeleteVertexArrays(1, &mesh.vao);
    glDeleteVertexArrays(1, &mesh.vao2);
    glDeleteBuffers(4, mesh.vbos);
}

/*Generate and load the texture*/
bool UCreateTexture(const char* filename, GLuint& textureId)
{
    int width, height, channels;
    unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
    if (image)
    {
        flipImageVertically(image, width, height, channels);

        glGenTextures(1, &textureId);
        glBindTexture(GL_TEXTURE_2D, textureId);

        // set the texture wrapping parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_MIRRORED_REPEAT);
        // set texture filtering parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        if (channels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (channels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            cout << "Not implemented to handle image with " << channels << " channels" << endl;
            return false;
        }

        glGenerateMipmap(GL_TEXTURE_2D);

        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

        return true;
    }

    // Error loading the image
    return false;
}


void UDestroyTexture(GLuint textureId)
{
    glGenTextures(1, &textureId);
}
// Implements the UCreateShaders function
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
    // Compilation and linkage error reporting
    int success = 0;
    char infoLog[512];

    // Create a Shader program object.
    programId = glCreateProgram();

    // Create the vertex and fragment shader objects
    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

    // Retrive the shader source
    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

    // Compile the vertex shader, and print compilation errors (if any)
    glCompileShader(vertexShaderId); // compile the vertex shader
    // check for shader compile errors
    glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glCompileShader(fragmentShaderId); // compile the fragment shader
    // check for shader compile errors
    glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    // Attached compiled shaders to the shader program
    glAttachShader(programId, vertexShaderId);
    glAttachShader(programId, fragmentShaderId);

    glLinkProgram(programId);   // links the shader program
    // check for linking errors
    glGetProgramiv(programId, GL_LINK_STATUS, &success);
    if (!success)
    {
        glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glUseProgram(programId);    // Uses the shader program

    return true;
}


void UDestroyShaderProgram(GLuint programId)
{
    glDeleteProgram(programId);
}

